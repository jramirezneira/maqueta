$(document).ready(function () {
	var sino = false;
	var calen = false;
	var nopoder = false;
	$('input.sino').change(function(){
		
		if( $(this).val() == '0' && $(this).is(':checked') ){
			$(this).parent().parent().find(".paisCont").css("display", "inline-block");
			if( calen ){
				sino = true;
			}else{
				sino = false;
			}
		}else if( $(this).val() == '1' && $(this).is(':checked') ){
			$(this).parent().parent().find(".paisCont").hide();
			sino = true;
		}
		btnActivo();
	})

	$(".button.primary.disabled").click(function(e){
		if( $(this).hasClass("disabled") ){
			e.preventDefault();
			//e.stopPropagation();
		}
	});
	$(".nmpoder").click(function(){
			nopoder = true;
			btnActivo();
	});
	$(".paisE, .ciudadE").focusout(function(){
		if( !$(".paisE").val() == '' && !$(".ciudadE").val() == '' && $(".inputCalendario").val() ){
			//$('#ccbtn').removeClass('disabled');
			calen = true;
			sino = true;
			btnActivo();
		}
	});
	$("#ccbtn").click(function(){
		if( $(".paisE ").val() == '' ){
			$(".paisE ").parent().addClass("error");
		}else{
			$(".paisE ").parent().removeClass("error");
		}
		if( $(".ciudadE").val() == '' ){
			$(".ciudadE ").parent().addClass("error");
		}else{
			$(".ciudadE ").parent().removeClass("error");
		}
	});
	function btnActivo(){
		if(sino && nopoder){
			$("#ccbtn").removeClass("disabled");
		}else{
			$("#ccbtn").addClass("disabled");
		}
	}

});
