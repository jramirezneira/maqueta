$(document).ready(function () {
 	$('.accordeon--head').click(function(event) {
		 event.preventdefault;
		 $(this).find('.icon-arrow-down').toggleClass('icon-arrow-up');
		 $(this).next().slideToggle();
		 $('#js-superclave').slideToggle();
   });
});
